package eu.robust.giraph;

import java.util.Map;

import junit.framework.TestCase;

import org.apache.giraph.utils.InternalVertexRunner;

import com.google.common.collect.Iterables;
import com.google.common.collect.Maps;

public class BreadthFirstSearchVertexTest extends TestCase {

	public void testToyData() throws Exception {

		String[] data = new String[] { "1	2	3", "2	3	4", "3	4", "4" };

		Map<String, String> params = Maps.newHashMap();
		params.put("bfs.sourceId", "1");

		Iterable<String> results = InternalVertexRunner.run(
				BreadthFirstSearchVertex.class,
				LongLongNullLongTextInputFormat.class,
				GenericVertexWithValueTextOutputFormat.class, params, data);

		Map<Long, Long> distances = parseDistances(results);

		assertEquals(4, distances.size());
		assertEquals(new Long(0), distances.get(1l));
		assertEquals(new Long(1), distances.get(2l));
		assertEquals(new Long(1), distances.get(3l));
		assertEquals(new Long(2), distances.get(4l));

	}

	private Map<Long, Long> parseDistances(Iterable<String> results) {
		Map<Long, Long> distances = Maps.newHashMapWithExpectedSize(Iterables
				.size(results));
		for (String line : results) {
			String[] tokens = line.split("\t");
			distances.put(Long.parseLong(tokens[0]), Long.parseLong(tokens[1]));
		}
		return distances;
	}

}
