package eu.robust.giraph;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.RecordWriter;
import org.mockito.Mockito;

import eu.robust.giraph.BreadthFirstSearchVertex;
import eu.robust.giraph.GenericVertexWithValueTextOutputFormat.GenericVertexWithValueWriter;
import junit.framework.TestCase;

public class GenericVertexWithValueTextOutputFormatTest extends TestCase {

	public void testGenericVertexWithValueWriter() throws Exception {

		// create mocks
		@SuppressWarnings("unchecked")
		RecordWriter<Text, Text> recordWriter = Mockito
				.mock(RecordWriter.class);

		// create writer
		GenericVertexWithValueWriter<LongWritable, LongWritable> writer = new GenericVertexWithValueWriter<LongWritable, LongWritable>(
				recordWriter);

		// create the vertex
		BreadthFirstSearchVertex vertex = new BreadthFirstSearchVertex();
		vertex.setVertexId(new LongWritable(1l));
		vertex.setVertexValue(new LongWritable(10l));

		// check the writer
		writer.writeVertex(vertex);
		Mockito.verify(recordWriter).write(new Text("1\t10"), null);

	}
}
