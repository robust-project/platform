package eu.robust.giraph;

import java.util.Iterator;

import junit.framework.TestCase;

import org.apache.giraph.graph.BasicVertex;
import org.apache.giraph.graph.GiraphJob;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.RecordReader;
import org.mockito.Mockito;

import eu.robust.giraph.LongLongNullLongTextInputFormat.LongLongNullLongVertexReader;

public class LongLongNullLongTextInputFormatTest extends TestCase {

	public void testLongLongNullLongVertexReader() throws Exception {

		// prepare the mocking environment
		@SuppressWarnings("unchecked")
		RecordReader<LongWritable, Text> recordReader = Mockito
				.mock(RecordReader.class);
		Mockito.when(recordReader.getCurrentValue()).thenReturn(
				new Text("1\t2\t3"));
		InputSplit inputSplit = Mockito.mock(InputSplit.class);
		@SuppressWarnings("rawtypes")
		Mapper.Context context = Mockito.mock(Mapper.Context.class);
		Configuration conf = new Configuration();
		conf.setClass(GiraphJob.VERTEX_CLASS, BreadthFirstSearchVertex.class,
				BasicVertex.class);
		Mockito.when(context.getConfiguration()).thenReturn(conf);

		// instantiate the reader
		LongLongNullLongVertexReader reader = new LongLongNullLongVertexReader(
				recordReader);
		reader.initialize(inputSplit, context);

		// get the vertex
		BreadthFirstSearchVertex vertex = (BreadthFirstSearchVertex) reader
				.getCurrentVertex();

		// check the vertex
		assertEquals(1l, vertex.getVertexId().get());
		Iterator<LongWritable> ancestors = vertex.iterator();
		assertTrue(ancestors.hasNext());
		assertEquals(2l, ancestors.next().get());
		assertTrue(ancestors.hasNext());
		assertEquals(3l, ancestors.next().get());
		assertFalse(ancestors.hasNext());

	}
}
