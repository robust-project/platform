package eu.robust.giraph;

import java.io.IOException;
import java.util.Iterator;

import org.apache.giraph.graph.EdgeListVertex;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.log4j.Logger;

public class BreadthFirstSearchVertex extends
		EdgeListVertex<LongWritable, LongWritable, NullWritable, LongWritable> {

	private static final Logger LOG = Logger
			.getLogger(BreadthFirstSearchVertex.class);

	public static final String SOURCE_ID = "bfs.sourceId";
	public static final long SOURCE_ID_DEFAULT = 1;

	@Override
	public void compute(Iterator<LongWritable> msgIterator) throws IOException {

		// initialize if needed
		if (getSuperstep() == 0) {
			setVertexValue(new LongWritable(Long.MAX_VALUE));
		}

		// get recent distance
		long distance = isSource() ? 0 : Long.MAX_VALUE;

		// get new distance
		while (msgIterator.hasNext()) {
			distance = Math.min(distance, msgIterator.next().get());
		}
		if (LOG.isDebugEnabled()) {
			LOG.debug("Vertex " + getVertexId() + " got distance = " + distance
					+ " vertex value = " + getVertexValue());
		}

		// check for change
		if (distance < getVertexValue().get()) {
			// set new distance
			setVertexValue(new LongWritable(distance));
			// send new distance
			for (LongWritable targetVertexId : this) {
				if (LOG.isDebugEnabled()) {
					LOG.debug("Vertex " + getVertexId() + " sent to "
							+ targetVertexId + " = " + (distance + 1));
				}
				sendMsg(targetVertexId, new LongWritable(distance + 1));
			}
		}
		voteToHalt();

	}

	/**
	 * Is this vertex the source id?
	 * 
	 * @return True if the source id
	 */
	private boolean isSource() {
		return getVertexId().get() == getContext().getConfiguration().getLong(
				SOURCE_ID, SOURCE_ID_DEFAULT);
	}

}
